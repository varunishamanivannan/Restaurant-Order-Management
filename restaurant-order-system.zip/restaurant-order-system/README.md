# 🍽️ Restaurant Order Management System

A simple SQL-based project to manage restaurant customers, menu, and orders.

## 📁 Project Structure
- `schema.sql` – SQL script to create the database schema.
- `sample_data.sql` – Example data to populate tables.
- `queries.sql` – Useful SQL queries to fetch data insights.
- `app.py` – (Optional) Python Flask backend to interact with the DB.

## 🚀 Getting Started

### 1. Create Database
Use the `schema.sql` file to set up the database schema:
```bash
sqlite3 restaurant.db < schema.sql
```

### 2. Insert Sample Data
```bash
sqlite3 restaurant.db < sample_data.sql
```

### 3. Run the App (if using Python Flask)
```bash
pip install -r requirements.txt
python app.py
```

## 🧠 Sample Queries
See `queries.sql` for:
- Total bill per order
- Most popular dish
- Orders per table

## 🛠️ Built With
- SQL (SQLite/MySQL compatible)
- Python (optional, Flask)
