from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('restaurant.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/dishes')
def get_dishes():
    conn = get_db_connection()
    dishes = conn.execute('SELECT * FROM dishes').fetchall()
    conn.close()
    return jsonify([dict(row) for row in dishes])

@app.route('/orders', methods=['POST'])
def create_order():
    data = request.get_json()
    customer_id = data['customer_id']
    items = data['items']  # List of {dish_id, quantity}
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    cur.execute('INSERT INTO orders (customer_id) VALUES (?)', (customer_id,))
    order_id = cur.lastrowid

    for item in items:
        cur.execute(
            'INSERT INTO order_items (order_id, dish_id, quantity) VALUES (?, ?, ?)',
            (order_id, item['dish_id'], item['quantity'])
        )

    conn.commit()
    conn.close()
    return jsonify({"message": "Order created", "order_id": order_id})

if __name__ == '__main__':
    app.run(debug=True)
