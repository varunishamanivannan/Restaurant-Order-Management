-- Dishes
INSERT INTO dishes (name, price, is_veg) VALUES
('Margherita Pizza', 8.99, 1),
('Chicken Burger', 6.49, 0),
('Pasta Alfredo', 7.99, 1),
('Grilled Chicken', 9.49, 0);

-- Customers
INSERT INTO customers (name, table_number) VALUES
('Alice', 1),
('Bob', 2);

-- Orders
INSERT INTO orders (customer_id) VALUES (1), (2);

-- Order Items
INSERT INTO order_items (order_id, dish_id, quantity) VALUES
(1, 1, 2),
(1, 3, 1),
(2, 2, 1),
(2, 4, 1);
