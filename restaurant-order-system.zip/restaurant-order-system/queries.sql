-- Total bill per order
SELECT o.order_id, c.name, SUM(d.price * oi.quantity) AS total_bill
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN dishes d ON oi.dish_id = d.dish_id
GROUP BY o.order_id;

-- Most popular dish
SELECT d.name, SUM(oi.quantity) AS total_ordered
FROM order_items oi
JOIN dishes d ON oi.dish_id = d.dish_id
GROUP BY d.name
ORDER BY total_ordered DESC
LIMIT 1;

-- Orders per table
SELECT table_number, COUNT(o.order_id) AS total_orders
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY table_number;
